import java.io.*;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

public class Lexer {

	private File input;
	private static HashMap<String,Token> stringTable;  // la struttura dati potrebbe essere una hash map
	private int state;
	private RandomAccessFile fr;

	public Lexer(){
		// la symbol table in questo caso la chiamiamo stringTable
		stringTable = new HashMap<String, Token>();
		state = 0;
		stringTable.put("if", new Token("IF"));
		stringTable.put("then", new Token("THEN"));
		stringTable.put("else", new Token ("ELSE"));
		stringTable.put("while", new Token("WHILE"));
		stringTable.put("int", new Token ("INT"));
		stringTable.put("float",new Token("FLOAT"));
		stringTable.put("do",new Token("DO"));
		// inserimento delle parole chiavi nella stringTable per evitare di scrivere un diagramma di transizione per ciascuna di esse (le parole chiavi verranno "catturate" dal diagramma di transizione e gestite e di conseguenza). IF poteva anche essere associato ad una costante numerica

	}

	public Boolean initialize(String filePath){
		File input= new File(filePath);

		try  {
			fr=new RandomAccessFile(input,"r");
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}


		return true;
	   // prepara file input per lettura e controlla errori


	}

	public Token nextToken()throws Exception{

		//Ad ogni chiamata del lexer (nextToken())
		//si resettano tutte le variabili utilizzate
		state = 0;
		String lessema = ""; //� il lessema riconosciuto
        char c='0';
        int content;

		while(true){

			 // legge un carattere da input e lancia eccezione quando incontra EOF per restituire null
			 //  per indicare che non ci sono pi� token
			try {
				if ((content = fr.read()) != -1) {
					c = (char) content;
				}
				else
				{
					fr.close();
					Token token= new Token("EOF");
					stringTable.put(lessema,token);
					return token;
				}
			}
			catch(IOException e) {
				return null;
			}


			//operatori relazionali ed assign
			switch(state) {
				case 0:
					if (c == '<') {
						state = 1;
						lessema += c;
						if (!hasNextChar()) {
							return relop(lessema);
						}break;
					}
					else if(c== '>'){
						state = 6;
						lessema += c;
						if (!hasNextChar()) {
							return relop(lessema);
						}break;
					}
					else if(c== '=') {
						state=5;
						lessema +=c;
						if (!hasNextChar()) {
							return relop(lessema);
						}
					}
					else{
						state=9;
						break;
					}
				case 5:
					return relop(lessema);

				case 1:
					if (c == '=') {
						state = 2;
						lessema += c;
					}
					else if (c == '>') {
						state = 3;
						lessema += c;
					}

					else if(c=='-'){
						state=32;
						lessema+=c;
					}

					else{
						state=4;
						retrack();
					}break;

				case 2:
					retrack();
					return(relop(lessema));
				case 3:
					retrack();
					return (relop(lessema));
				case 4:
					retrack();
					return(relop(lessema));
				case 32:
					if(c=='-')
					{
						state=33;
						lessema+=c;
					}
					else {
						retrack();
						retrack();
						lessema="<";
						return relop(lessema);

					}
				case 33:
					return assign(lessema);

				case 6:
					if (c == '=') {
						lessema += c;
						state=7;
						if (!hasNextChar()) {
							return relop(lessema);
						}break;
					}
					else
					{
						state=8;
					}
				case 7:
					retrack();
					return relop(lessema);
				case 8:
					retrack();
					return relop(lessema);
			}

			//id
			switch(state) {
				case 9:
					if (Character.isLetter(c)) {
						lessema += c;
						// Nel caso in cui il file � terminato ma ho letto qualcosa di valido
						// devo lanciare il token (altrimenti perderei l'ultimo token, troncato per l'EOF) 
						if(!hasNextChar()){
							return installID(lessema);
						}
						state = 10;
					}
					else {
						state=12;
					}
					break;


				case 10:
					while(Character.isLetterOrDigit(c))
					{
						lessema+=c;
						c=(char)fr.read();
					}
					state=11;


				case 11:
					retrack();
					return installID(lessema);

			}

			//unsigned numbers
			switch(state){
				case 12:
					if(Character.isDigit(c)){
						state = 13;
						lessema += c;
						if(c=='0')
						{
							state=19;
							if((char)fr.read()=='.')
							{
								lessema+='.';
								state=14;
							}
							else {
								retrack();
							}
						}


						if(!hasNextChar())
						{
							return(installNUMBER(lessema));
						}

					}
					else{
						state=22;

					}break;
				case 13:
					while(Character.isDigit(c))
					{
						lessema+=c;
						c=(char)fr.read();
					}
					if(c=='.')
					{
						state=14;
						lessema+=c;
						break;
					}
					if(c == 'E'|| c=='e')
					{
						state=16;
						lessema+=c;
						break;
					}
					state=20;
				case 20:
					retrack();
					return installNUMBER(lessema);
				case 14:
					if(Character.isDigit(c))
					{
						lessema+=c;
						state=15;
					}
					else {
						state=22;
						retrack();
						retrack();
						lessema=lessema.substring(0,lessema.length()-1);
						return installNUMBER(lessema);
					}
					break;
				case 15:
					while(Character.isDigit(c))
					{
						lessema+=c;
						c=(char)fr.read();
					}
					if(c == 'E' || c=='e')
					{
						state=16;
						lessema+=c;
						break;
					}
					state=21;
				case 21:
					retrack();
					return installNUMBER(lessema);
				case 16:
					if(c=='+' || c=='-')
					{
						state=17;
						lessema+=c;
						break;
					}
					if(Character.isDigit(c))
					{
						lessema+=c;
						state=18;break;
					}
					else
					{
						state=22;
						retrack();
						retrack();
						lessema=lessema.substring(0,lessema.length()-1);
						return installNUMBER(lessema);
					}
				case 17:
					if(Character.isDigit(c))
					{
						lessema+=c;
						state=18;
					}
					else
					{
						state=22;
						retrack();
						retrack();
						retrack();
						lessema=lessema.substring(0,lessema.length()-2);
						return installNUMBER(lessema);
					}break;
				case 18:
					while(Character.isDigit(c))
					{
						lessema+=c;
						c=(char)fr.read();
					}
					state=19;
				case 19:
					retrack();
					return installNUMBER(lessema);

			}

			//delim
			switch (state){
				case 22:
					if (Character.isWhitespace(c)) {
						state = 23;
					} else{
						state=25;
					}
					break;
				case 23:

					while(Character.isWhitespace(c)){
						c=(char)fr.read();
					}
					state= 24;
				case 24:
					retrack();
					state=0;
					break;
			}

			//separatori
			switch (state){
				case 25:

					if(c=='('){
						state=26;
						lessema+=c;
						if(!hasNextChar())
						{
							return separ(lessema);
						}
					}

					else if(c==')'){
						state=27;
						lessema+=c;
						if(!hasNextChar())
						{
							return separ(lessema);
						}
					}

					else if(c=='{'){
						state=28;
						lessema+=c;
						if(!hasNextChar())
						{
							return separ(lessema);
						}
					}

					else if(c=='}'){
						state=29;
						lessema+=c;
						if(!hasNextChar())
						{
							return separ(lessema);
						}
					}

					else if(c==';'){
						state=30;
						lessema+=c;
						if(!hasNextChar())
						{
							return separ(lessema);
						}
					}

					else if(c==','){
						state=31;
						lessema+=c;
						if(!hasNextChar())
						{
							return separ(lessema);
						}
					}
					else{
						state=34;
						lessema+=c;
					}break;

				case 26:
					retrack();
					return separ(lessema);

				case 27:
					retrack();
					return separ(lessema);

				case 28:
					retrack();
					return separ(lessema);

				case 29:
					retrack();
					return separ(lessema);

				case 30:
					retrack();
					return separ(lessema);

				case 31:
					retrack();
					return separ(lessema);
			}

			//errori
			switch(state)
			{
				case 34:
					return installERROR(lessema);
			}


		}//end while
	}//end method
		
  
private Token installID(String lessema){
	Token token;
	
	//utilizzo come chiave della hashmap il lessema
	if(stringTable.containsKey(lessema))
		return stringTable.get(lessema);
	else{
		token =  new Token("ID", lessema);
		stringTable.put(lessema, token);
		return token;
	}
}

private Token assign(String lessema)
{
	Token token =  new Token("ASSIGN");
	stringTable.put(lessema, token);
	return token;
}


private Token installSPACE(String lessema)
{
	Token token =  new Token("DEL",lessema);
	stringTable.put(lessema, token);
	return token;
}

private Token installERROR(String lessema)
{
	Token token =  new Token("ERROR",lessema);
	stringTable.put(lessema, token);
	return token;
}

private Token relop (String lessema) {
		Token token;
		if (stringTable.containsKey(lessema))
			return stringTable.get(lessema);
		else {
			if (lessema.toString().equals("<")) {
				token = new Token("relop", "LT");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals("<=")) {
				token = new Token("relop", "LE");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals("<>")) {
				token = new Token("relop", "NE");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals("=")) {
				token = new Token("relop", "EQ");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals(">=")) {
				token = new Token("relop", "GE");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals(">")) {
				token = new Token("relop", "GT");
				stringTable.put(lessema, token);
				return token;
			}

		}
		return null;
	}

	private Token separ (String lessema) {
		Token token;
		if (stringTable.containsKey(lessema))
			return stringTable.get(lessema);
		else {
			if (lessema.toString().equals(",")) {
				token = new Token("COMMA");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals(";")) {
				token = new Token("SEMI");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals("(")) {
				token = new Token("PTOPEN");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals(")")) {
				token = new Token("PTCLOSE");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals("{")) {
				token = new Token("PGOPEN");
				stringTable.put(lessema, token);
				return token;
			}
			if (lessema.toString().equals("}")) {
				token = new Token("PGCLOSE");
				stringTable.put(lessema, token);
				return token;
			}

		}
		return null;
	}

private Token installNUMBER(String lessema)
{
	Token token =  new Token("NUMBER",lessema);
	stringTable.put(lessema, token);
	return token;
}


private void retrack(){
	try {
		fr.seek(fr.getFilePointer()-1);
	} catch (IOException e) {
		e.printStackTrace();
	}
}

private boolean hasNextChar(){
	try {
		if(fr.read()==-1)
		{
			return false;
		}

	} catch (IOException e) {
		e.printStackTrace();
	}
	retrack();
	return true;

}

}
